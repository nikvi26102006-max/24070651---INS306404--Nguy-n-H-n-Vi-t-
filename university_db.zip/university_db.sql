-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 04, 2026 at 05:48 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_code` varchar(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `credits` int(11) NOT NULL DEFAULT 3,
  `department_id` int(11) NOT NULL,
  `instructor_id` int(11) NOT NULL
) ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `name`, `credits`, `department_id`, `instructor_id`) VALUES
(1, 'MIS101', 'Hệ thống thông tin quản lý', 3, 1, 1),
(2, 'IT101', 'Lập trình cơ bản', 3, 2, 2),
(3, 'BA101', 'Nguyên lý quản trị kinh doanh', 3, 3, 3),
(4, 'ECO101', 'Kinh tế vi mô', 3, 4, 4),
(5, 'FIN101', 'Tài chính doanh nghiệp', 3, 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `code`, `created_at`) VALUES
(1, 'Hệ thống thông tin', 'MIS', '2026-10-04 14:29:17'),
(2, 'Công nghệ thông tin', 'IT', '2026-10-04 14:29:17'),
(3, 'Quản trị kinh doanh', 'BA', '2026-10-04 14:29:17'),
(4, 'Kinh tế', 'ECO', '2026-10-04 14:29:17'),
(5, 'Tài chính - Ngân hàng', 'FIN', '2026-10-04 14:29:17');

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `enrollment_date` date NOT NULL DEFAULT curdate(),
  `grade` decimal(3,2) DEFAULT NULL,
  `status` enum('Enrolled','Completed','Dropped') NOT NULL DEFAULT 'Enrolled'
) ;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`id`, `student_id`, `course_id`, `semester_id`, `enrollment_date`, `grade`, `status`) VALUES
(1, 1, 1, 4, '2025-09-05', 8.50, 'Completed'),
(2, 1, 2, 4, '2025-09-05', 8.00, 'Completed'),
(3, 2, 1, 4, '2025-09-06', 7.50, 'Completed'),
(4, 2, 2, 4, '2025-09-06', 8.20, 'Completed'),
(5, 3, 3, 4, '2025-09-07', 9.00, 'Completed'),
(6, 3, 4, 4, '2025-09-07', 8.75, 'Completed'),
(7, 4, 4, 5, '2026-02-05', NULL, 'Enrolled'),
(8, 4, 5, 5, '2026-02-05', NULL, 'Enrolled'),
(9, 5, 1, 5, '2026-02-06', NULL, 'Enrolled'),
(10, 5, 5, 5, '2026-02-06', NULL, 'Enrolled'),
(11, 1, 3, 5, '2026-02-07', NULL, 'Enrolled'),
(12, 2, 4, 5, '2026-02-07', NULL, 'Enrolled');

-- --------------------------------------------------------

--
-- Table structure for table `instructors`
--

CREATE TABLE `instructors` (
  `id` int(11) NOT NULL,
  `instructor_code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `instructors`
--

INSERT INTO `instructors` (`id`, `instructor_code`, `name`, `email`, `phone`, `department_id`) VALUES
(1, 'GV001', 'Nguyễn Văn Minh', 'minh.nguyen@university.edu.vn', '0912345678', 1),
(2, 'GV002', 'Trần Thị Lan', 'lan.tran@university.edu.vn', '0923456789', 2),
(3, 'GV003', 'Lê Hoàng Nam', 'nam.le@university.edu.vn', '0934567890', 3),
(4, 'GV004', 'Phạm Thị Hương', 'huong.pham@university.edu.vn', '0945678901', 4),
(5, 'GV005', 'Đỗ Quang Huy', 'huy.do@university.edu.vn', '0956789012', 5);

-- --------------------------------------------------------

--
-- Table structure for table `semesters`
--

CREATE TABLE `semesters` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('Upcoming','Active','Completed') NOT NULL DEFAULT 'Upcoming'
) ;

--
-- Dumping data for table `semesters`
--

INSERT INTO `semesters` (`id`, `name`, `start_date`, `end_date`, `status`) VALUES
(1, 'Học kỳ 1 - 2024', '2024-09-01', '2025-01-15', 'Completed'),
(2, 'Học kỳ 2 - 2024', '2025-02-01', '2025-06-15', 'Completed'),
(3, 'Học kỳ Hè - 2025', '2025-07-01', '2025-08-31', 'Completed'),
(4, 'Học kỳ 1 - 2025', '2025-09-01', '2026-01-15', 'Completed'),
(5, 'Học kỳ 2 - 2025', '2026-02-01', '2026-06-15', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `gender` enum('Nam','Nữ','Khác') NOT NULL DEFAULT 'Khác',
  `date_of_birth` date DEFAULT NULL,
  `department_id` int(11) NOT NULL,
  `gpa` decimal(3,2) DEFAULT 0.00
) ;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_code`, `name`, `email`, `phone`, `gender`, `date_of_birth`, `department_id`, `gpa`) VALUES
(1, 'SV001', 'Nguyễn Minh Anh', 'minhanh@student.edu.vn', '0981000001', 'Nữ', '2006-03-15', 1, 3.45),
(2, 'SV002', 'Trần Quốc Bảo', 'quocbao@student.edu.vn', '0981000002', 'Nam', '2006-07-20', 2, 3.20),
(3, 'SV003', 'Lê Thu Hà', 'thuha@student.edu.vn', '0981000003', 'Nữ', '2006-01-10', 3, 3.75),
(4, 'SV004', 'Phạm Đức Anh', 'ducanh@student.edu.vn', '0981000004', 'Nam', '2006-11-05', 4, 2.95),
(5, 'SV005', 'Đỗ Ngọc Mai', 'ngocmai@student.edu.vn', '0981000005', 'Nữ', '2006-09-25', 5, 3.60);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `course_code` (`course_code`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `instructor_id` (`instructor_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`,`course_id`,`semester_id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `semester_id` (`semester_id`);

--
-- Indexes for table `instructors`
--
ALTER TABLE `instructors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `instructor_code` (`instructor_code`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `semesters`
--
ALTER TABLE `semesters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_code` (`student_code`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD KEY `department_id` (`department_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `instructors`
--
ALTER TABLE `instructors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `semesters`
--
ALTER TABLE `semesters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `courses_ibfk_2` FOREIGN KEY (`instructor_id`) REFERENCES `instructors` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `enrollments_ibfk_3` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `instructors`
--
ALTER TABLE `instructors`
  ADD CONSTRAINT `instructors_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
